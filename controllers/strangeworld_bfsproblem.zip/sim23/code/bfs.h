#pragma once
#include "lib.h"
#include "bot.h"
#include "tile.h"
#include "victim.h"

int bfs(int tile);
int move2Tile(int cur, int target);
int gohome(int tile);