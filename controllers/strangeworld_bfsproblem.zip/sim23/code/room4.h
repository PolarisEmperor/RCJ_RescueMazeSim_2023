#pragma once
#include "bot.h"
#include "tile.h"
#include "wallTrace.h"

void doRoom4();