#pragma once
#include "lib.h"
#include "tile.h"
#include "bot.h"

char checkVisualVictim(webots::Camera *);
void sendVictimSignal(char ch);