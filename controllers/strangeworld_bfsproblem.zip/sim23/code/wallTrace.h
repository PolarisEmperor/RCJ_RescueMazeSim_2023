#pragma once
#include "bot.h"
#include "victim.h"

int room4_wallTrace();